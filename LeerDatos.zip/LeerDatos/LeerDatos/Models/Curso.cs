﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LeerDatos.Models
{
    public class Curso
    {
        public int CursoId { get; set; }
        public string Titulo { get; set; }
        public string Descripcion { get; set; }
        public DateTime FechaPublicacion { get; set; }

        public Precio PrecioPromocion { get; set; }                           // Relación uno a uno
        public ICollection<Comentario> ComentarioLista { get; set; }         // Relación uno a muchos

        public ICollection<CursoInstructor> InstructorLink { get; set; }     // Relación muchos a muchos
    }
}
