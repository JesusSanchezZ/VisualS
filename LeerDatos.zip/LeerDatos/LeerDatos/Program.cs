using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LeerDatos
{
    public class Program
    {
        public static void Main(string[] args)
        {
            using (var db = new AppVentaCursosContext())
            {
                // Lectura de tablas sin relaciones
                var cursos = db.Curso.AsNoTracking();
                foreach (var curso in cursos)
                {
                    Console.WriteLine(curso.Descripcion);
                }

                // Lectura de tablas con relaci�n uno a uno
                var cursos1 = db.Curso.Include(p => p.PrecioPromocion).AsNoTracking();   // arreglo IQuetyable
                foreach (var curso in cursos1)
                {
                    Console.WriteLine(curso.Titulo + "----" + curso.Descripcion + "-----" + curso.FechaPublicacion + "--------" + curso.PrecioPromocion.PrecioActual);

                }

                // Lectura de tablas con relaci�n uno a muchos
                var cursos2 = db.Curso.Include(c => c.ComentarioLista).AsNoTracking();
                foreach (var curso in cursos2)
                {
                    Console.WriteLine(curso.Titulo);
                    foreach (var comentario in curso.ComentarioLista)
                    {
                        Console.WriteLine("*************************" + comentario.ComentarioTexto);
                    }
                }

                // Lectura de tablas con relaci�n muchos a muchos
                var curso3 = db.Curso.Include(c => c.InstructorLink).ThenInclude(ci => ci.Instructor);
            }

            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
