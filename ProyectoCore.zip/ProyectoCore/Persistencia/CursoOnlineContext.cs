using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Dominio;

namespace Persistencia
{
    public class CursoOnlineContext : IdentityDbContext<Usuario> //IdentityContext<Usuario> //DbContext para hacer las migraciones se cambia a IdentityContext<>
    {
        public CursoOnlineContext(DbContextOptions options) : base(options){

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder){
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<CursoInstructor>().HasKey(ci => new {ci.InstructorId, ci.CursoId});
        }

        public DbSet<Comentario> Comentario {get;set;}
        public DbSet<Curso> Curso {get;set;}
        public DbSet<CursoInstructor> CursoInstructor {get;set;}
        public DbSet<Instructor> Instructor {get;set;}
        public DbSet<Precio> Precio {get;set;}
    }
}


/*
intalación de la herramienta para las migraciones
    dotnet tool install --global dotnet-ef --version 5.0.0

creación de la migración, especificamos el archivo en donde se van a guardar los archivos de migración
y el proyecto que lo va a ejecutar
    dotnet-ef migrations add IdentityCoreInicial -p Persistencia/ -s WebApi/

direccionamos la carpeta webapi y ejecutamos el comando:
    dotnet watch run

*/