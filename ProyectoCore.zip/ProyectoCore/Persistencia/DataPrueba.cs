using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Dominio;

namespace Persistencia
{
    public class DataPrueba
    {
        public static async Task InsertarData(CursoOnlineContext context, UserManager<Usuario> usuarioManager){
            // si no existen usuarios en la base de datos
            if(!usuarioManager.Users.Any()){
                var usuario = new Usuario{ NombreCompleto = "Vaxi Drez", UserName="vaxidrez", Email="vaxi.drez@gmail.com"};
                await usuarioManager.CreateAsync(usuario, "Password123$");
            }
        }
    }
}