using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dominio
{
    public class Curso
    {
        public int CursoId {get; set;}
        public string Titulo {get;set;}
        public string Descripcion {get; set;}
        public DateTime FechaPublicacion {get;set;}
        public byte[] FotoPortada {get;set;}

        // Relación uno a uno con Precio
        public Precio PrecioPromocion {get;set;}
        // Realacion uno a muchos con Comentario
        public ICollection<Comentario> ComentarioLista {get;set;}
        // Realacion muchos a muchos entre Curso e Instructor
        public ICollection<CursoInstructor> InstructoresLink {get; set;}
    }
}