using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Aplicacion.ManejadorError
{
    public class ManejadorExcepcion : Exception
    {
        public HttpStatusCode Codigo {get;}
        public Object Errores {get;}
        public ManejadorExcepcion(HttpStatusCode codigo, object errores = null){
            Codigo = codigo;
            Errores = errores;
        }
    }
}