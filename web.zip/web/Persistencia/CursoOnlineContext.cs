﻿using Dominio;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persistencia
{
    public class CursoOnlineContext : DbContext
    {
        public CursoOnlineContext(DbContextOptions options) : base(options) {
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CursoInstructor>().HasKey(ci => new { ci.InstructorId, ci.CursoId });
        }

        public Microsoft.EntityFrameworkCore.DbSet<Comentario> Comentario { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Curso> Curso { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<CursoInstructor> CursoInstructor { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Instructor> Instructor { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Precio> Precio { get; set; }
    }
}
