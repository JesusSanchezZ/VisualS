﻿using System;

namespace Aplicacion
{
    public class Class1
    {
    }
}
