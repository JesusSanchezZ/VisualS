﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dominio;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Persistencia;

namespace webAPI.Controllers
{
    // [ApiController]
    // [Route("[controller]")]
    // public class WeatherForecastController : ControllerBase
    // {
        // private static readonly string[] Summaries = new[]
        // {
        //     "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        // };

        // private readonly ILogger<WeatherForecastController> _logger;

        // public WeatherForecastController(ILogger<WeatherForecastController> logger)
        // {
        //     _logger = logger;
        // }

        // [HttpGet]
        // public IEnumerable<WeatherForecast> Get()
        // {
        //     var rng = new Random();
        //     return Enumerable.Range(1, 5).Select(index => new WeatherForecast
        //     {
        //         Date = DateTime.Now.AddDays(index),
        //         TemperatureC = rng.Next(-20, 55),
        //         Summary = Summaries[rng.Next(Summaries.Length)]
        //     })
        //     .ToArray();
        // }
    // }

    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : Controller{
        private readonly CursoOnlineContext context;
        // Inyección de dependencias para hacer que el servicio sea visible por todos los controladores...
        // |_   es la creación de un objeto indirectamente usando un servicio externo de una clase
        public WeatherForecastController(CursoOnlineContext _context)
        {
            this.context = _context;
        }

        [HttpGet]
        public IEnumerable<Curso> Get(){
            return context.Curso.ToList();
        }
    }
}
